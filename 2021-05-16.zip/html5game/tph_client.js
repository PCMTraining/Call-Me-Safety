/*
 * Server IP Address
 */
var server_ip = 'ws://192.168.1.200:8080';
/**
 * Audio variable
 */
var audio = null;
/**
 * Full screen parameter.
 */
var full_screen = {lock: false};
/**
 * Network socket
 */
var network = null;
/**
 * Network events
 */
var events = [];

/**
 * Is this app?
 * @returns {number} Is is an application, or browser (0)
 */
function isApp() {
	if(typeof App !== 'undefined')
		return 1;
	else 
		return 0;
}

/**
 * Connect to server.
 */
function networkOpen(){
	network = new WebSocket(server_ip);
	network.addEventListener('open', function(){
		events.push('connected');
	});
	network.addEventListener('message', function(e){
		events.push(e.data);
	});
	network.addEventListener('error',function(){
		events.push('error');
		network.close();
	});
	network.addEventListener('close', function(){
		events.push('close');
	});
}

/**
 * Get a network event.
 */
function networkReceive() {
	if(events.length > 0)
		return events.shift();
	else
		return "";
}

/**
 * Send a message to the server.
 * @param {string} data JSON string
 */
function networkSend(data) {
	if(network !== null)
		if(network.readyState === 1)
			network.send(data);
}

/**
 * Play audio file.
 * @param {string} file Audio file location.
 */
function audioPlay(file) {
	audio = new Audio(file);
	audio.loop = true;
	audio.play();
}

/**
 * Stop audio play.
 */
function audioStop() {
	if(audio!=null) {
		audio.pause();
		audio.currentTime = 0;
	}
}

/**
 * Go fullscreen!
 * @returns {number} is it fullscreen?
 */
function fullScreen() {
	if (isApp() === 0) {
		if (!isFullScreen() && !full_screen.lock) {
			var canvas = document.getElementById('canvas');

			if (canvas.requestFullscreen)
				canvas.requestFullscreen();
			else if (canvas.mozRequestFullScreen)
				canvas.mozRequestFullScreen();
			else if (canvas.webkitRequestFullscreen)
				canvas.webkitRequestFullscreen();
			else if (canvas.msRequestFullscreen)
				canvas.msRequestFullscreen();

            return isFullScreen();
		} else
            return 1;
	}

    return 0;
}

/**
 * Exit full screen
 */
function closeFullScreen() {
	if (document.exitFullscreen)
		document.exitFullscreen();
	else if (document.mozCancelFullScreen)
		document.mozCancelFullScreen();
	else if (document.webkitExitFullscreen)
		document.webkitExitFullscreen();
	else if (document.msExitFullscreen)
		document.msExitFullscreen();
}

/**
 * Check fullscreen status.
 * @returns {number} is it fullscreen?
 */
function isFullScreen() {
	return window.innerWidth / screen.width > 0.9 && window.innerHeight / screen.height > 0.9;
}

/**
 * Returns current browser width.
 * @returns {number} Current browser width.
 */
function windowInnerWidth() {
	return window.innerWidth;
}

/**
 * Returns current browser height.
 * @returns {number} Current browser height.
 */
function windowInnerHeight() {
	return window.innerHeight;
}

/**
 * Load data stored on device. (string only)
 * @param {string} loc Data location.
 * @returns {string} Data received.
 */
function loadData(loc) {
	var dt = '';

	if (isApp()===0){
		var d=localStorage.getItem(loc)

		if (d!=null)
			dt=d;
	} else
		dt=App.loadData(loc);

	return dt;
}

/**
 * Save data to device.
 * @param {string} loc Data location.
 * @param {string} data Data to be saved.
 */
function saveData(loc,data) {
	if (isApp() === 0)
		localStorage.setItem(loc,data);
	else
		App.saveData(loc,data);
}

/**
 * Show system alert dialog
 * @param {string} str text string
 */
function dialogAlert(str) {
	if (isApp() === 0) {
		full_screen.lock = true;
		closeFullScreen();
		alert(str);
		full_screen.lock = false;
		fullScreen();
	} else
		App.alert(str);
}

/**
 * Show confirmation dialog
 * @param {string} name Name of data to be returned.
 * @param {string} str String of hint text
 */
function dialogConfirm(name,str) {
	if (isApp() === 0) {
		full_screen.lock = true;
		closeFullScreen();
		var input = prompt(str);
		full_screen.lock = false;
		fullScreen();
	} else {
		App.confirm(name,str);
		inpput = '';
	}
}

/**
 * Show system prompt dialog.
 * @returns String of result or empty string.
 */
function dialogPrompt(name, str) {
	var input;

	if (isApp() === 0) {
		full_screen.lock = true
		closeFullScreen()
		var input = prompt(str)
		full_screen.lock = false
		fullScreen()
	} else {
		App.prompt(name,str);
		input = '';
	}

	return input;
}
